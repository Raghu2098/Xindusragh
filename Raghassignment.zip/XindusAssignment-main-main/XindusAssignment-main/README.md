# XindusAssignment
make sure to have nodejs installed 
Clone the project and run npm install 
